package com.medrate.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.medrate.app.domain.calculations.*
import com.medrate.app.ui.components.*
import com.medrate.app.ui.theme.Tints
import com.medrate.app.viewmodels.AppViewModel
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter

@Composable
fun HomeScreen(vm: AppViewModel, go: (String) -> Unit) {
    val meds by vm.medicines.collectAsStateWithLifecycle()
    val logs by vm.doseLogs.collectAsStateWithLifecycle()
    val acts by vm.activities.collectAsStateWithLifecycle()
    val sleeps by vm.sleeps.collectAsStateWithLifecycle()
    val meals by vm.meals.collectAsStateWithLifecycle()
    val records by vm.records.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()

    val today = LocalDate.now()
    val hour = LocalTime.now().hour
    val greet = if (hour < 12) "Good morning" else if (hour < 18) "Good afternoon" else "Good evening"
    val title = if (settings.name.isBlank()) greet else "$greet, ${settings.name}"

    val doses = remember(meds, logs) { Doses.forDate(today, meds, logs) }
    val taken = doses.count { it.status == Doses.TAKEN }
    val next = doses.firstOrNull { it.status == Doses.PENDING && LocalTime.parse(it.time) >= LocalTime.now() }
    val steps = Summaries.stepsOn(acts, today)
    val minutes = Summaries.minutesOn(acts, today)
    val sleepMin = Summaries.latestSleepMinutes(sleeps, today)
    val energy = remember(sleeps, acts) { EnergyScore.estimate(sleepMin, Summaries.activeMinutes3Day(acts, today)) }
    val load = ActivityLoad.forDate(acts, today)
    val todayMeals = meals.filter { SleepCalc.fromMillis(it.dateTimeMillis).toLocalDate() == today }
    val kcal = todayMeals.mapNotNull { it.calories }.sum()
    val recent = remember(sleeps, acts, meals, records) { Summaries.recent(sleeps, acts, meals, records) }
    val hasAnyActivity = acts.any { it.date == today.toString() }

    Screen(title, subtitle = today.format(DateTimeFormatter.ofPattern("EEEE, MMMM d"))) {
        item {
            MCard {
                Text("Today", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Stat("Steps", if (hasAnyActivity) "$steps" else "—")
                    Stat("Sleep", sleepMin?.let { SleepCalc.format(it) } ?: "—")
                    Stat("Doses", if (doses.isEmpty()) "—" else "$taken/${doses.size}")
                }
                Spacer(Modifier.height(4.dp))
                Caption("Steps and sleep are entered manually.")
            }
        }
        item {
            CategoryCard(
                "Energy score (experimental)", Tints.Energy,
                if (energy.score == null) "Add a sleep record to see a wellness estimate." else "Experimental wellness estimate, not a medical score.",
                big = energy.score?.let { "$it / 100" } ?: "Not enough data"
            ) { go("energy") }
        }
        item {
            Row(Modifier.height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                CategoryCard(
                    "Daily activity", Tints.Activity,
                    if (hasAnyActivity) "$minutes min exercise" else "Add steps or exercise",
                    Modifier.weight(1f).fillMaxHeight(), big = if (hasAnyActivity) "$steps steps" else null
                ) { go("activity") }
                CategoryCard(
                    "Sleep", Tints.Sleep, if (sleepMin == null) "Add sleep record" else "Last night",
                    Modifier.weight(1f).fillMaxHeight(), big = sleepMin?.let { SleepCalc.format(it) }
                ) { go("sleep") }
            }
        }
        item {
            Row(Modifier.height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                CategoryCard(
                    "Food", Tints.Food,
                    if (todayMeals.isEmpty()) "Ready to log your first meal?" else "${todayMeals.size} meal(s) logged" + if (kcal > 0) " · $kcal kcal entered" else "",
                    Modifier.weight(1f).fillMaxHeight()
                ) { go("food") }
                CategoryCard(
                    "Medications", Tints.Medication,
                    when {
                        meds.isEmpty() -> "Add a medication to get reminders."
                        doses.isEmpty() -> "No doses scheduled today"
                        next != null -> "$taken of ${doses.size} taken · next ${next.time} ${next.medicine.name}"
                        else -> "$taken of ${doses.size} doses taken"
                    },
                    Modifier.weight(1f).fillMaxHeight()
                ) { go("medication") }
            }
        }
        item {
            Row(Modifier.height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                CategoryCard(
                    "Daily cardio load (estimate)", Tints.Cardio,
                    if (load > 0) "Activity-load estimate from your entries" else "Add exercise with an intensity",
                    Modifier.weight(1f).fillMaxHeight(), big = if (load > 0) "$load AU" else null
                ) { go("cardio") }
                CategoryCard(
                    "Health records", Tints.Records,
                    if (records.isEmpty()) "Add your first health record." else "${records.size} saved record(s)",
                    Modifier.weight(1f).fillMaxHeight()
                ) { go("records") }
            }
        }
        item {
            CategoryCard(
                "Vascular load", Tints.Vascular,
                "No validated score is available. Record measurements you already have.",
                big = "Data only"
            ) { go("vascular") }
        }
        item {
            CategoryCard(
                "AI Health Assistant", Tints.Assistant,
                "Not connected. Browse general health education and medication safety basics."
            ) { go("assistant") }
        }
        item { SectionTitle("Recent activity") }
        if (recent.isEmpty()) item { MCard { EmptyState("Nothing logged yet. Entries you add will appear here.") } }
        else item {
            MCard {
                recent.forEachIndexed { i, r ->
                    if (i > 0) HorizontalDivider(Modifier.padding(vertical = 8.dp))
                    Text(r.text)
                    Caption(friendlyDate(SleepCalc.fromMillis(r.millis).toLocalDate()))
                }
            }
        }
    }
}

@Composable
private fun Stat(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, style = MaterialTheme.typography.titleLarge)
        Caption(label)
    }
}
