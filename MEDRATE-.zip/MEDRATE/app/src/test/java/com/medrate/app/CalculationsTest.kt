package com.medrate.app

import com.medrate.app.domain.calculations.*
import org.junit.Assert.*
import org.junit.Test
import java.time.LocalDate
import java.time.LocalTime

class CalculationsTest {
    @Test fun sleepAcrossMidnight() {
        val (b, w) = SleepCalc.resolve(LocalDate.of(2026, 1, 2), LocalTime.of(23, 0), LocalTime.of(7, 0))
        assertEquals(480L, SleepCalc.minutesBetween(b, w))
    }

    @Test fun sleepSameDayNap() {
        val (b, w) = SleepCalc.resolve(LocalDate.of(2026, 1, 2), LocalTime.of(13, 0), LocalTime.of(14, 30))
        assertEquals(90L, SleepCalc.minutesBetween(b, w))
    }

    @Test fun sleepValidity() {
        assertFalse(SleepCalc.isValid(0))
        assertTrue(SleepCalc.isValid(480))
        assertFalse(SleepCalc.isValid(21 * 60))
    }

    @Test fun energyNeedsSleep() = assertNull(EnergyScore.estimate(null, 60).score)

    @Test fun energySleepOnly() = assertEquals(50, EnergyScore.estimate(240, null).score)

    @Test fun energyFull() = assertEquals(100, EnergyScore.estimate(480, 90).score)

    @Test fun energyCapsAtMax() = assertEquals(100, EnergyScore.estimate(700, 900).score)

    @Test fun activityLoad() {
        assertEquals(60, ActivityLoad.load(30, "MODERATE"))
        assertEquals(90, ActivityLoad.load(30, "HIGH"))
        assertNull(ActivityLoad.load(30, ""))
    }
}
