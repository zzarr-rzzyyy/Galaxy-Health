package com.medrate.app.data.database

import android.content.Context
import androidx.room.*
import com.medrate.app.data.entities.*
import kotlinx.coroutines.flow.Flow

@Dao
interface MedrateDao {
    @Query("SELECT * FROM medicines ORDER BY name COLLATE NOCASE") fun medicines(): Flow<List<Medicine>>
    @Query("SELECT * FROM medicines") suspend fun medicinesOnce(): List<Medicine>
    @Query("SELECT * FROM medicines WHERE id = :id") suspend fun medicine(id: Long): Medicine?
    @Insert suspend fun insertMedicine(m: Medicine): Long
    @Update suspend fun updateMedicine(m: Medicine)
    @Query("DELETE FROM medicines WHERE id = :id") suspend fun deleteMedicineById(id: Long)
    @Query("DELETE FROM dose_logs WHERE medicineId = :id") suspend fun deleteLogsFor(id: Long)

    @Query("SELECT * FROM dose_logs") fun doseLogs(): Flow<List<DoseLog>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putDose(d: DoseLog)
    @Query("DELETE FROM dose_logs WHERE medicineId = :id AND date = :date AND time = :time")
    suspend fun clearDose(id: Long, date: String, time: String)

    @Query("SELECT * FROM activities ORDER BY date DESC, id DESC") fun activities(): Flow<List<ActivityEntry>>
    @Upsert suspend fun upsertActivity(a: ActivityEntry)
    @Delete suspend fun deleteActivity(a: ActivityEntry)

    @Query("SELECT * FROM sleep_entries ORDER BY endMillis DESC") fun sleeps(): Flow<List<SleepEntry>>
    @Upsert suspend fun upsertSleep(s: SleepEntry)
    @Delete suspend fun deleteSleep(s: SleepEntry)

    @Query("SELECT * FROM meals ORDER BY dateTimeMillis DESC") fun meals(): Flow<List<MealEntry>>
    @Upsert suspend fun upsertMeal(m: MealEntry)
    @Delete suspend fun deleteMeal(m: MealEntry)

    @Query("SELECT * FROM health_records ORDER BY date DESC, id DESC") fun records(): Flow<List<HealthRecord>>
    @Upsert suspend fun upsertRecord(r: HealthRecord)
    @Delete suspend fun deleteRecord(r: HealthRecord)
}

// Version 1. Future schema changes must ship explicit Migration objects (no destructive fallback).
@Database(
    entities = [Medicine::class, DoseLog::class, ActivityEntry::class, SleepEntry::class, MealEntry::class, HealthRecord::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun dao(): MedrateDao

    companion object {
        @Volatile private var instance: AppDatabase? = null
        fun get(context: Context): AppDatabase = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(context.applicationContext, AppDatabase::class.java, "medrate.db")
                .build().also { instance = it }
        }
    }
}
