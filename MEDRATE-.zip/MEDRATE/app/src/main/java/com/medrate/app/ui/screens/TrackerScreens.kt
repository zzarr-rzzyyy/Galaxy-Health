package com.medrate.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.medrate.app.data.entities.*
import com.medrate.app.domain.calculations.SleepCalc
import com.medrate.app.domain.calculations.Summaries
import com.medrate.app.ui.components.*
import com.medrate.app.ui.theme.Tints
import com.medrate.app.viewmodels.AppViewModel
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime

// ---------------------------------------------------------------- Sleep
@Composable
fun SleepScreen(vm: AppViewModel, onBack: () -> Unit) {
    val sleeps by vm.sleeps.collectAsStateWithLifecycle()
    val today = LocalDate.now()
    var editing by remember { mutableStateOf<SleepEntry?>(null) }
    var show by remember { mutableStateOf(false) }
    val days = (6 downTo 0).map { today.minusDays(it.toLong()) }
    val perDay = days.map { d -> sleeps.filter { it.wakeDate() == d }.sumOf { SleepCalc.minutesBetween(it.startMillis, it.endMillis) } }
    val recorded = perDay.filter { it > 0 }

    Screen("Sleep", onBack, fabLabel = "Add sleep", onFab = { editing = null; show = true }) {
        item {
            MCard {
                Text("Last 7 days", style = MaterialTheme.typography.titleMedium)
                if (recorded.isEmpty()) EmptyState("No sleep recorded yet.", "Add sleep record") { editing = null; show = true }
                else {
                    Text("Average ${SleepCalc.format(recorded.average().toLong())} on recorded days")
                    Spacer(Modifier.height(8.dp))
                    BarChart(perDay.map { it / 60f }, days.map { dayLabel(it) }, Tints.Sleep)
                }
                Caption("Sleep is entered manually. MEDRATE does not detect sleep automatically.")
            }
        }
        item { SectionTitle("History") }
        if (sleeps.isEmpty()) item { MCard { EmptyState("Your sleep records will appear here.") } }
        else items(sleeps, key = { it.id }) { s ->
            MCard(onClick = { editing = s; show = true }) {
                Text("${friendlyDate(s.wakeDate())} · ${SleepCalc.format(SleepCalc.minutesBetween(s.startMillis, s.endMillis))}", style = MaterialTheme.typography.titleMedium)
                Caption("${hhmm(SleepCalc.fromMillis(s.startMillis).toLocalTime())} to ${hhmm(SleepCalc.fromMillis(s.endMillis).toLocalTime())}")
                if (s.notes.isNotBlank()) Text(s.notes)
            }
        }
    }
    if (show) SleepDialog(editing, { show = false }, { vm.save(it); show = false }, { vm.delete(it); show = false })
}

@Composable
private fun SleepDialog(initial: SleepEntry?, onDismiss: () -> Unit, onSave: (SleepEntry) -> Unit, onDelete: (SleepEntry) -> Unit) {
    val ctx = LocalContext.current
    var wakeDate by remember { mutableStateOf(initial?.wakeDate() ?: LocalDate.now()) }
    var bed by remember { mutableStateOf(initial?.let { SleepCalc.fromMillis(it.startMillis).toLocalTime() } ?: LocalTime.of(23, 0)) }
    var wake by remember { mutableStateOf(initial?.let { SleepCalc.fromMillis(it.endMillis).toLocalTime() } ?: LocalTime.of(7, 0)) }
    var notes by remember { mutableStateOf(initial?.notes ?: "") }
    var error by remember { mutableStateOf<String?>(null) }
    val (b, w) = SleepCalc.resolve(wakeDate, bed, wake)
    val minutes = SleepCalc.minutesBetween(b, w)

    FormDialog(
        if (initial == null) "Add sleep" else "Edit sleep", error, onDismiss,
        onSave = {
            if (!SleepCalc.isValid(minutes)) error = "Check your times. Duration must be between 1 minute and 20 hours."
            else onSave(SleepEntry(initial?.id ?: 0, SleepCalc.toMillis(b), SleepCalc.toMillis(w), notes.trim()))
        },
        onDelete = initial?.let { s -> { onDelete(s) } }
    ) {
        PickerButton("Wake-up date", friendlyDate(wakeDate)) { pickDate(ctx, wakeDate) { wakeDate = it } }
        PickerButton("Went to bed", hhmm(bed)) { pickTime(ctx, bed) { bed = it } }
        PickerButton("Woke up", hhmm(wake)) { pickTime(ctx, wake) { wake = it } }
        Text(if (SleepCalc.isValid(minutes)) "Duration: ${SleepCalc.format(minutes)}" else "Duration: check times")
        Field("Notes (optional)", notes, { notes = it }, singleLine = false)
    }
}

// ---------------------------------------------------------------- Activity
private val activityTypes = listOf("Walking", "Running", "Cycling", "Workout", "Other")
private val intensityLabels = listOf("None", "Low", "Moderate", "High")

@Composable
fun ActivityScreen(vm: AppViewModel, onBack: () -> Unit) {
    val acts by vm.activities.collectAsStateWithLifecycle()
    val today = LocalDate.now()
    var editing by remember { mutableStateOf<ActivityEntry?>(null) }
    var show by remember { mutableStateOf(false) }
    val days = (6 downTo 0).map { today.minusDays(it.toLong()) }
    val stepsPerDay = days.map { Summaries.stepsOn(acts, it) }

    Screen("Daily activity", onBack, fabLabel = "Add activity", onFab = { editing = null; show = true }) {
        item {
            MCard {
                Text("Today", style = MaterialTheme.typography.titleMedium)
                if (acts.none { it.date == today.toString() }) EmptyState("No activity recorded today.", "Add activity") { editing = null; show = true }
                else Text("${Summaries.stepsOn(acts, today)} steps · ${Summaries.minutesOn(acts, today)} min exercise")
                Caption("All values are entered manually. This version does not read a step sensor.")
            }
        }
        if (acts.isNotEmpty()) item {
            MCard {
                Text("Steps, last 7 days", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                BarChart(stepsPerDay.map { it.toFloat() }, days.map { dayLabel(it) }, Tints.Activity)
            }
        }
        item { SectionTitle("History") }
        if (acts.isEmpty()) item { MCard { EmptyState("Your activities will appear here.") } }
        else items(acts, key = { it.id }) { a ->
            MCard(onClick = { editing = a; show = true }) {
                Text("${a.type} · ${friendlyDate(LocalDate.parse(a.date))}", style = MaterialTheme.typography.titleMedium)
                Text("${a.steps} steps · ${a.minutes} min" + if (a.intensity.isNotEmpty()) " · ${a.intensity.lowercase().replaceFirstChar { it.uppercase() }}" else "")
                Caption("Entered manually")
            }
        }
    }
    if (show) ActivityDialog(editing, { show = false }, { vm.save(it); show = false }, { vm.delete(it); show = false })
}

@Composable
private fun ActivityDialog(initial: ActivityEntry?, onDismiss: () -> Unit, onSave: (ActivityEntry) -> Unit, onDelete: (ActivityEntry) -> Unit) {
    val ctx = LocalContext.current
    var date by remember { mutableStateOf(initial?.date?.let { LocalDate.parse(it) } ?: LocalDate.now()) }
    var type by remember { mutableStateOf(initial?.type ?: "Walking") }
    var steps by remember { mutableStateOf(initial?.steps?.takeIf { it > 0 }?.toString() ?: "") }
    var minutes by remember { mutableStateOf(initial?.minutes?.takeIf { it > 0 }?.toString() ?: "") }
    var intensity by remember { mutableStateOf(initial?.intensity?.takeIf { it.isNotEmpty() }?.lowercase()?.replaceFirstChar { it.uppercase() } ?: "None") }
    var error by remember { mutableStateOf<String?>(null) }

    FormDialog(
        if (initial == null) "Add activity" else "Edit activity", error, onDismiss,
        onSave = {
            val s = if (steps.isBlank()) 0 else steps.toIntOrNull()
            val m = if (minutes.isBlank()) 0 else minutes.toIntOrNull()
            error = when {
                s == null || m == null -> "Enter whole numbers."
                s !in 0..100_000 || m !in 0..1440 -> "Steps must be 0 to 100000 and minutes 0 to 1440."
                s == 0 && m == 0 -> "Enter steps or exercise minutes."
                else -> null
            }
            if (error == null) onSave(ActivityEntry(initial?.id ?: 0, date.toString(), type, s!!, m!!, if (intensity == "None") "" else intensity.uppercase()))
        },
        onDelete = initial?.let { a -> { onDelete(a) } }
    ) {
        PickerButton("Date", friendlyDate(date)) { pickDate(ctx, date) { date = it } }
        ChipRow(activityTypes, type) { type = it }
        Field("Steps (manual)", steps, { steps = it.filter(Char::isDigit) }, KeyboardType.Number)
        Field("Exercise minutes", minutes, { minutes = it.filter(Char::isDigit) }, KeyboardType.Number)
        Text("Intensity (optional)", style = MaterialTheme.typography.labelLarge)
        ChipRow(intensityLabels, intensity) { intensity = it }
    }
}

// ---------------------------------------------------------------- Food
private val mealCategories = listOf("Breakfast", "Lunch", "Dinner", "Snack")

@Composable
fun FoodScreen(vm: AppViewModel, onBack: () -> Unit) {
    val meals by vm.meals.collectAsStateWithLifecycle()
    var editing by remember { mutableStateOf<MealEntry?>(null) }
    var show by remember { mutableStateOf(false) }
    val grouped = meals.groupBy { SleepCalc.fromMillis(it.dateTimeMillis).toLocalDate() }.toSortedMap(compareByDescending { it })

    Screen("Food", onBack, fabLabel = "Log meal", onFab = { editing = null; show = true }) {
        item { Caption("Calories are optional estimates you enter yourself. MEDRATE does not look up nutrition values.") }
        if (meals.isEmpty()) item { MCard { EmptyState("Ready to log your first meal?", "Log meal") { editing = null; show = true } } }
        grouped.forEach { (day, list) ->
            val kcal = list.mapNotNull { it.calories }.sum()
            item(key = "h$day") { SectionTitle(friendlyDate(day) + if (kcal > 0) " · $kcal kcal entered" else "") }
            items(list.sortedBy { it.dateTimeMillis }, key = { it.id }) { m ->
                MCard(onClick = { editing = m; show = true }) {
                    Text("${hhmm(SleepCalc.fromMillis(m.dateTimeMillis).toLocalTime())}  ${m.name}", style = MaterialTheme.typography.titleMedium)
                    Caption(m.category + (m.calories?.let { " · $it kcal (estimate)" } ?: ""))
                    if (m.notes.isNotBlank()) Text(m.notes)
                }
            }
        }
    }
    if (show) MealDialog(editing, { show = false }, { vm.save(it); show = false }, { vm.delete(it); show = false })
}

@Composable
private fun MealDialog(initial: MealEntry?, onDismiss: () -> Unit, onSave: (MealEntry) -> Unit, onDelete: (MealEntry) -> Unit) {
    val ctx = LocalContext.current
    val start = initial?.let { SleepCalc.fromMillis(it.dateTimeMillis) } ?: LocalDateTime.now()
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var category by remember { mutableStateOf(initial?.category ?: "Lunch") }
    var date by remember { mutableStateOf(start.toLocalDate()) }
    var time by remember { mutableStateOf(start.toLocalTime().withSecond(0).withNano(0)) }
    var kcal by remember { mutableStateOf(initial?.calories?.toString() ?: "") }
    var notes by remember { mutableStateOf(initial?.notes ?: "") }
    var error by remember { mutableStateOf<String?>(null) }

    FormDialog(
        if (initial == null) "Log meal" else "Edit meal", error, onDismiss,
        onSave = {
            val c = if (kcal.isBlank()) null else kcal.toIntOrNull()
            error = when {
                name.isBlank() -> "Enter a meal name."
                kcal.isNotBlank() && (c == null || c !in 0..10_000) -> "Calories must be a whole number from 0 to 10000."
                else -> null
            }
            if (error == null) onSave(MealEntry(initial?.id ?: 0, name.trim(), category, SleepCalc.toMillis(LocalDateTime.of(date, time)), c, notes.trim()))
        },
        onDelete = initial?.let { m -> { onDelete(m) } }
    ) {
        Field("Meal name", name, { name = it })
        ChipRow(mealCategories, category) { category = it }
        PickerButton("Date", friendlyDate(date)) { pickDate(ctx, date) { date = it } }
        PickerButton("Time", hhmm(time)) { pickTime(ctx, time) { time = it } }
        Field("Calories (optional estimate)", kcal, { kcal = it.filter(Char::isDigit) }, KeyboardType.Number)
        Field("Notes (optional)", notes, { notes = it }, singleLine = false)
    }
}

// ---------------------------------------------------------------- Health records
val recordCategories = listOf("Weight", "Blood pressure", "Heart rate", "Lab result", "Other")

@Composable
fun RecordsScreen(vm: AppViewModel, onBack: () -> Unit) {
    val records by vm.records.collectAsStateWithLifecycle()
    var editing by remember { mutableStateOf<HealthRecord?>(null) }
    var show by remember { mutableStateOf(false) }
    var filter by remember { mutableStateOf("All") }
    val titles = listOf("All") + records.map { it.title }.distinct()
    val shown = if (filter in titles) (if (filter == "All") records else records.filter { it.title == filter }) else records
    val numeric = shown.filter { it.value != null }.sortedBy { it.date }

    Screen("Health records", onBack, fabLabel = "Add record", onFab = { editing = null; show = true }) {
        item { Caption("Records are entered by you. MEDRATE does not collect or interpret these measurements.") }
        if (records.isEmpty()) item { MCard { EmptyState("No records yet. Add a measurement or result you already have.", "Add record") { editing = null; show = true } } }
        else {
            item { ChipRow(titles, if (filter in titles) filter else "All") { filter = it } }
            if (filter != "All" && numeric.size >= 2) item {
                MCard {
                    Text("$filter trend" + numeric.first().unit.let { if (it.isNotBlank()) " ($it)" else "" }, style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(8.dp))
                    LineChart(numeric.map { it.value!!.toFloat() }, Tints.Records)
                    Caption("${numeric.first().date} to ${numeric.last().date}")
                }
            }
            items(shown, key = { it.id }) { r ->
                MCard(onClick = { editing = r; show = true }) {
                    Text(r.title + (r.value?.let { " · ${fmt(it)} ${r.unit}".trimEnd() } ?: ""), style = MaterialTheme.typography.titleMedium)
                    Caption("${r.category} · ${friendlyDate(LocalDate.parse(r.date))}")
                    if (r.notes.isNotBlank()) Text(r.notes)
                }
            }
        }
    }
    if (show) RecordDialog(editing, { show = false }, { vm.save(it); show = false }, { vm.delete(it); show = false })
}

@Composable
private fun RecordDialog(initial: HealthRecord?, onDismiss: () -> Unit, onSave: (HealthRecord) -> Unit, onDelete: (HealthRecord) -> Unit) {
    val ctx = LocalContext.current
    var category by remember { mutableStateOf(initial?.category ?: "Weight") }
    var title by remember { mutableStateOf(initial?.title ?: "Weight") }
    var date by remember { mutableStateOf(initial?.date?.let { LocalDate.parse(it) } ?: LocalDate.now()) }
    var value by remember { mutableStateOf(initial?.value?.let { fmt(it) } ?: "") }
    var unit by remember { mutableStateOf(initial?.unit ?: "") }
    var notes by remember { mutableStateOf(initial?.notes ?: "") }
    var error by remember { mutableStateOf<String?>(null) }

    FormDialog(
        if (initial == null) "Add record" else "Edit record", error, onDismiss,
        onSave = {
            val v = if (value.isBlank()) null else value.replace(',', '.').toDoubleOrNull()
            error = when {
                title.isBlank() -> "Enter a title."
                value.isNotBlank() && v == null -> "Value must be a number."
                else -> null
            }
            if (error == null) onSave(HealthRecord(initial?.id ?: 0, title.trim(), category, date.toString(), v, unit.trim(), notes.trim()))
        },
        onDelete = initial?.let { r -> { onDelete(r) } }
    ) {
        ChipRow(recordCategories, category) { c ->
            if (title.isBlank() || title == category) title = c
            category = c
        }
        Field("Title", title, { title = it })
        PickerButton("Date", friendlyDate(date)) { pickDate(ctx, date) { date = it } }
        Field("Value (optional)", value, { value = it }, KeyboardType.Decimal)
        Field("Unit (optional)", unit, { unit = it })
        if (category == "Blood pressure") Caption("Tip: enter the systolic number as the value and write the diastolic number in notes.")
        Field("Notes (optional)", notes, { notes = it }, singleLine = false)
    }
}
