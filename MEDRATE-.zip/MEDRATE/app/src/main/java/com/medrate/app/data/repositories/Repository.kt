package com.medrate.app.data.repositories

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import com.medrate.app.data.database.AppDatabase
import com.medrate.app.data.database.MedrateDao
import com.medrate.app.data.entities.*
import com.medrate.app.notifications.Reminders
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext

data class Settings(val name: String = "", val theme: String = "system", val remindersEnabled: Boolean = true)

private val Context.dataStore by preferencesDataStore("settings")

class SettingsStore(private val ctx: Context) {
    private val nameKey = stringPreferencesKey("name")
    private val themeKey = stringPreferencesKey("theme")
    private val remKey = booleanPreferencesKey("reminders")

    val settings: Flow<Settings> = ctx.dataStore.data.map {
        Settings(it[nameKey] ?: "", it[themeKey] ?: "system", it[remKey] ?: true)
    }

    suspend fun setName(v: String) { ctx.dataStore.edit { it[nameKey] = v } }
    suspend fun setTheme(v: String) { ctx.dataStore.edit { it[themeKey] = v } }
    suspend fun setReminders(v: Boolean) { ctx.dataStore.edit { it[remKey] = v } }
}

class Repository(private val ctx: Context, val dao: MedrateDao, private val store: SettingsStore) {
    val settings: Flow<Settings> = store.settings

    suspend fun saveMedicine(m: Medicine) {
        val old = if (m.id != 0L) dao.medicine(m.id) else null
        old?.let { Reminders.cancel(ctx, it) }
        val saved = if (m.id == 0L) m.copy(id = dao.insertMedicine(m)) else m.also { dao.updateMedicine(it) }
        if (store.settings.first().remindersEnabled) Reminders.schedule(ctx, saved)
    }

    suspend fun deleteMedicine(m: Medicine) {
        Reminders.cancel(ctx, m)
        dao.deleteLogsFor(m.id)
        dao.deleteMedicineById(m.id)
    }

    suspend fun setDose(medicineId: Long, date: String, time: String, status: String?) {
        if (status == null) dao.clearDose(medicineId, date, time)
        else dao.putDose(DoseLog(medicineId = medicineId, date = date, time = time, status = status))
    }

    suspend fun setReminders(enabled: Boolean) {
        store.setReminders(enabled)
        val meds = dao.medicinesOnce()
        if (enabled) Reminders.scheduleAll(ctx, meds) else Reminders.cancelAll(ctx, meds)
    }

    suspend fun rescheduleAll() = Reminders.rescheduleFromDb(ctx)
    suspend fun setName(v: String) = store.setName(v)
    suspend fun setTheme(v: String) = store.setTheme(v)

    /** Deletes every health record and cancels all reminders. Settings are kept. */
    suspend fun deleteAll() {
        Reminders.cancelAll(ctx, dao.medicinesOnce())
        withContext(Dispatchers.IO) { AppDatabase.get(ctx).clearAllTables() }
    }
}
