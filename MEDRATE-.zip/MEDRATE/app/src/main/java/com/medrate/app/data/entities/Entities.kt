package com.medrate.app.data.entities

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

@Entity(tableName = "medicines")
data class Medicine(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    /** Typed by the user from a label or clinician instructions. MEDRATE never suggests doses. */
    val doseInstructions: String,
    val notes: String,
    val startDate: String,
    val endDate: String?,
    /** Comma separated HH:mm values. */
    val times: String
) {
    fun timeList(): List<String> = times.split(",").filter { it.isNotBlank() }
}

@Entity(
    tableName = "dose_logs",
    indices = [Index(value = ["medicineId", "date", "time"], unique = true)]
)
data class DoseLog(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val medicineId: Long,
    val date: String,
    val time: String,
    /** TAKEN or SKIPPED. Absence of a row means PENDING. */
    val status: String
)

@Entity(tableName = "activities")
data class ActivityEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val date: String,
    val type: String,
    val steps: Int,
    val minutes: Int,
    /** "", LOW, MODERATE or HIGH. */
    val intensity: String
)

@Entity(tableName = "sleep_entries")
data class SleepEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val startMillis: Long,
    val endMillis: Long,
    val notes: String
) {
    fun wakeDate(): LocalDate =
        Instant.ofEpochMilli(endMillis).atZone(ZoneId.systemDefault()).toLocalDate()
}

@Entity(tableName = "meals")
data class MealEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val category: String,
    val dateTimeMillis: Long,
    val calories: Int?,
    val notes: String
)

@Entity(tableName = "health_records")
data class HealthRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val category: String,
    val date: String,
    val value: Double?,
    val unit: String,
    val notes: String
)
