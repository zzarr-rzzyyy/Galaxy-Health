package com.medrate.app.ui.screens

import android.content.Intent
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.app.NotificationManagerCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.medrate.app.data.entities.Medicine
import com.medrate.app.domain.calculations.Doses
import com.medrate.app.ui.components.*
import com.medrate.app.ui.theme.Tints
import com.medrate.app.viewmodels.AppViewModel
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime

@Composable
fun MedicationScreen(vm: AppViewModel) {
    val ctx = LocalContext.current
    val meds by vm.medicines.collectAsStateWithLifecycle()
    val logs by vm.doseLogs.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    val today = LocalDate.now()
    val doses = remember(meds, logs) { Doses.forDate(today, meds, logs) }
    val adherence = remember(meds, logs) { Doses.adherence(meds, logs, today, LocalDateTime.now()) }
    var editing by remember { mutableStateOf<Medicine?>(null) }
    var showForm by remember { mutableStateOf(false) }
    var notifOk by remember { mutableStateOf(NotificationManagerCompat.from(ctx).areNotificationsEnabled()) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        notifOk = NotificationManagerCompat.from(ctx).areNotificationsEnabled()
    }

    Screen("Medication", fabLabel = "Add medicine", onFab = { editing = null; showForm = true }) {
        item {
            MCard {
                if (!notifOk || !settings.remindersEnabled) {
                    Text("Reminders are off", style = MaterialTheme.typography.titleMedium)
                    Text(
                        if (!settings.remindersEnabled) "Medication reminders are switched off in Profile."
                        else "Notifications are disabled for MEDRATE, so you will not be alerted for doses."
                    )
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (!notifOk && Build.VERSION.SDK_INT >= 33) {
                            Button(onClick = { launcher.launch(android.Manifest.permission.POST_NOTIFICATIONS) }) { Text("Allow notifications") }
                        }
                        if (!notifOk) OutlinedButton(onClick = {
                            ctx.startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName))
                        }) { Text("Open settings") }
                    }
                    Spacer(Modifier.height(6.dp))
                }
                Caption("Reminders use Android's alarm system. Delivery can be delayed by battery saver or device settings, so timing is not guaranteed. Do not rely on MEDRATE as your only reminder.")
            }
        }
        item {
            MCard {
                Text("7-day adherence", style = MaterialTheme.typography.titleMedium)
                if (adherence.second == 0) Text("No doses have come due yet.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                else Text("${adherence.first} of ${adherence.second} due doses marked taken (${adherence.first * 100 / adherence.second}%)")
            }
        }
        item { SectionTitle("Today") }
        if (doses.isEmpty()) item {
            MCard {
                EmptyState(
                    if (meds.isEmpty()) "No medicines yet. Add one to get reminders." else "No doses scheduled today.",
                    if (meds.isEmpty()) "Add medicine" else null
                ) { editing = null; showForm = true }
            }
        } else items(doses, key = { "${it.medicine.id}-${it.time}" }) { d ->
            MCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("${d.time}  ${d.medicine.name}", style = MaterialTheme.typography.titleMedium)
                        if (d.medicine.doseInstructions.isNotBlank()) Caption(d.medicine.doseInstructions)
                        if (d.status != Doses.PENDING) Text(d.status.lowercase().replaceFirstChar { it.uppercase() }, color = Tints.Medication)
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    if (d.status == Doses.PENDING) {
                        TextButton(onClick = { vm.setDose(d.medicine.id, d.date.toString(), d.time, Doses.TAKEN) }) { Text("Taken") }
                        TextButton(onClick = { vm.setDose(d.medicine.id, d.date.toString(), d.time, Doses.SKIPPED) }) { Text("Skip") }
                    } else TextButton(onClick = { vm.setDose(d.medicine.id, d.date.toString(), d.time, null) }) { Text("Undo") }
                }
            }
        }
        item { SectionTitle("My medicines") }
        if (meds.isEmpty()) item { MCard { EmptyState("Your medicines will be listed here.") } }
        else items(meds, key = { it.id }) { m ->
            MCard(onClick = { editing = m; showForm = true }) {
                Text(m.name, style = MaterialTheme.typography.titleMedium)
                Caption("Times: ${m.timeList().sorted().joinToString(", ")}")
                if (m.doseInstructions.isNotBlank()) Text(m.doseInstructions)
                Caption("From ${m.startDate}" + (m.endDate?.let { " to $it" } ?: ""))
            }
        }
        item { Caption("Enter dose instructions exactly as written on your label or given by your clinician. MEDRATE never suggests doses.") }
    }

    if (showForm) MedicineDialog(
        initial = editing,
        onDismiss = { showForm = false },
        onSave = { vm.saveMedicine(it); showForm = false },
        onDelete = { m -> vm.deleteMedicine(m); showForm = false }
    )
}

@Composable
private fun MedicineDialog(initial: Medicine?, onDismiss: () -> Unit, onSave: (Medicine) -> Unit, onDelete: (Medicine) -> Unit) {
    val ctx = LocalContext.current
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var dose by remember { mutableStateOf(initial?.doseInstructions ?: "") }
    var notes by remember { mutableStateOf(initial?.notes ?: "") }
    var start by remember { mutableStateOf(initial?.startDate?.let { LocalDate.parse(it) } ?: LocalDate.now()) }
    var end by remember { mutableStateOf(initial?.endDate?.let { LocalDate.parse(it) }) }
    var times by remember { mutableStateOf(initial?.timeList() ?: emptyList()) }
    var error by remember { mutableStateOf<String?>(null) }
    var confirmDelete by remember { mutableStateOf(false) }

    FormDialog(
        if (initial == null) "Add medicine" else "Edit medicine", error, onDismiss,
        onSave = {
            val e = end
            error = when {
                name.isBlank() -> "Enter a medicine name."
                times.isEmpty() -> "Add at least one reminder time."
                e != null && e.isBefore(start) -> "The end date cannot be before the start date."
                else -> null
            }
            if (error == null) onSave(
                Medicine(
                    id = initial?.id ?: 0, name = name.trim(), doseInstructions = dose.trim(), notes = notes.trim(),
                    startDate = start.toString(), endDate = e?.toString(), times = times.distinct().sorted().joinToString(",")
                )
            )
        },
        onDelete = if (initial != null) ({ confirmDelete = true }) else null
    ) {
        Field("Medicine name", name, { name = it })
        Field("Dose instructions (from your label or clinician)", dose, { dose = it }, singleLine = false)
        Field("Notes (optional)", notes, { notes = it }, singleLine = false)
        PickerButton("Start date", friendlyDate(start)) { pickDate(ctx, start) { start = it } }
        PickerButton("End date (optional)", end?.let { friendlyDate(it) } ?: "None") { pickDate(ctx, end ?: start) { end = it } }
        if (end != null) TextButton(onClick = { end = null }) { Text("Clear end date") }
        Text("Reminder times", style = MaterialTheme.typography.labelLarge)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            times.sorted().forEach { t -> AssistChip(onClick = { times = times - t }, label = { Text("$t  ✕") }) }
        }
        OutlinedButton(onClick = { pickTime(ctx, LocalTime.of(8, 0)) { t -> times = (times + hhmm(t)).distinct() } }, modifier = Modifier.fillMaxWidth()) {
            Text("Add reminder time")
        }
    }
    if (confirmDelete && initial != null) AlertDialog(
        onDismissRequest = { confirmDelete = false },
        title = { Text("Delete ${initial.name}?") },
        text = { Text("This removes the medicine, its dose history and its reminders. This cannot be undone.") },
        confirmButton = { TextButton(onClick = { onDelete(initial) }) { Text("Delete", color = MaterialTheme.colorScheme.error) } },
        dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancel") } }
    )
}
