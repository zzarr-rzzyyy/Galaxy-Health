package com.medrate.app.viewmodels

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.medrate.app.data.database.AppDatabase
import com.medrate.app.data.entities.*
import com.medrate.app.data.repositories.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = Repository(app, AppDatabase.get(app).dao(), SettingsStore(app))

    private fun <T> Flow<T>.state(initial: T) = stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), initial)

    val medicines = repo.dao.medicines().state(emptyList())
    val doseLogs = repo.dao.doseLogs().state(emptyList())
    val activities = repo.dao.activities().state(emptyList())
    val sleeps = repo.dao.sleeps().state(emptyList())
    val meals = repo.dao.meals().state(emptyList())
    val records = repo.dao.records().state(emptyList())
    val settings = repo.settings.state(Settings())

    private val _message = MutableStateFlow<String?>(null)
    val message = _message.asStateFlow()
    fun clearMessage() { _message.value = null }

    init { io { repo.rescheduleAll() } }

    private fun io(block: suspend () -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            try { block() } catch (e: Exception) { _message.value = "Something went wrong. Your change may not have been saved." }
        }
    }

    fun saveMedicine(m: Medicine) = io { repo.saveMedicine(m) }
    fun deleteMedicine(m: Medicine) = io { repo.deleteMedicine(m) }
    fun setDose(id: Long, date: String, time: String, status: String?) = io { repo.setDose(id, date, time, status) }

    fun save(a: ActivityEntry) = io { repo.dao.upsertActivity(a) }
    fun delete(a: ActivityEntry) = io { repo.dao.deleteActivity(a) }
    fun save(s: SleepEntry) = io { repo.dao.upsertSleep(s) }
    fun delete(s: SleepEntry) = io { repo.dao.deleteSleep(s) }
    fun save(m: MealEntry) = io { repo.dao.upsertMeal(m) }
    fun delete(m: MealEntry) = io { repo.dao.deleteMeal(m) }
    fun save(r: HealthRecord) = io { repo.dao.upsertRecord(r) }
    fun delete(r: HealthRecord) = io { repo.dao.deleteRecord(r) }

    fun setName(v: String) = io { repo.setName(v) }
    fun setTheme(v: String) = io { repo.setTheme(v) }
    fun setReminders(v: Boolean) = io { repo.setReminders(v) }
    fun deleteAll() = io { repo.deleteAll() }
}
