package com.medrate.app.ai

enum class AssistantMode(val label: String) {
    GENERAL("Health education"),
    MEDICATION("Medication information")
}

data class ChatMessage(val fromUser: Boolean, val text: String)

/**
 * Plug a real provider in by implementing this interface and assigning it to [AiConfig.provider].
 * Never embed API keys in the app; call your own secure backend. Only the typed chat text should be sent,
 * never stored health records, unless the user gives explicit consent.
 */
interface AiProvider {
    val name: String
    val isConfigured: Boolean
    suspend fun reply(mode: AssistantMode, history: List<ChatMessage>): String
}

object NoProvider : AiProvider {
    override val name = "None"
    override val isConfigured = false
    override suspend fun reply(mode: AssistantMode, history: List<ChatMessage>): String =
        throw UnsupportedOperationException("No AI provider is configured.")
}

object AiConfig {
    var provider: AiProvider = NoProvider
}

/** Safety instructions a future provider integration should send as its system prompt. */
object SystemPrompts {
    private const val COMMON = "You provide general health education only. Never diagnose, never calculate or change personal " +
        "medication doses, never tell anyone to stop essential medication, never invent facts, citations or drug interactions, " +
        "state uncertainty, list urgent warning signs, and advise emergency care or a qualified professional when appropriate."

    fun forMode(mode: AssistantMode): String = when (mode) {
        AssistantMode.GENERAL -> "$COMMON Explain health concepts in plain language."
        AssistantMode.MEDICATION -> "$COMMON Only explain information from the user's own label text or verified reference material " +
            "they provide, and recommend checking interactions with a pharmacist or doctor."
    }
}
