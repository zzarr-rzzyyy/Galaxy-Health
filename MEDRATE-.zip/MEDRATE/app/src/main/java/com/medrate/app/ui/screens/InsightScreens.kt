package com.medrate.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.medrate.app.domain.calculations.*
import com.medrate.app.ui.components.*
import com.medrate.app.ui.theme.Tints
import com.medrate.app.viewmodels.AppViewModel
import java.time.LocalDate

@Composable
fun HealthHubScreen(go: (String) -> Unit) {
    Screen("Health") {
        item {
            Row(Modifier.height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                CategoryCard("Sleep", Tints.Sleep, "Track your sleep", Modifier.weight(1f).fillMaxHeight()) { go("sleep") }
                CategoryCard("Daily activity", Tints.Activity, "Steps and exercise", Modifier.weight(1f).fillMaxHeight()) { go("activity") }
            }
        }
        item {
            Row(Modifier.height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                CategoryCard("Food", Tints.Food, "Meal log", Modifier.weight(1f).fillMaxHeight()) { go("food") }
                CategoryCard("Health records", Tints.Records, "Your own measurements", Modifier.weight(1f).fillMaxHeight()) { go("records") }
            }
        }
        item {
            Row(Modifier.height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                CategoryCard("Energy score", Tints.Energy, "Experimental estimate", Modifier.weight(1f).fillMaxHeight()) { go("energy") }
                CategoryCard("Daily cardio load", Tints.Cardio, "Activity-load estimate", Modifier.weight(1f).fillMaxHeight()) { go("cardio") }
            }
        }
        item {
            Row(Modifier.height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                CategoryCard("Vascular load", Tints.Vascular, "Entered data only", Modifier.weight(1f).fillMaxHeight()) { go("vascular") }
                CategoryCard("AI assistant", Tints.Assistant, "Health education", Modifier.weight(1f).fillMaxHeight()) { go("assistant") }
            }
        }
    }
}

@Composable
fun EnergyScreen(vm: AppViewModel, onBack: () -> Unit, go: (String) -> Unit) {
    val sleeps by vm.sleeps.collectAsStateWithLifecycle()
    val acts by vm.activities.collectAsStateWithLifecycle()
    val today = LocalDate.now()
    val sleepMin = Summaries.latestSleepMinutes(sleeps, today)
    val act3 = Summaries.activeMinutes3Day(acts, today)
    val res = remember(sleeps, acts) { EnergyScore.estimate(sleepMin, act3) }

    Screen("Energy score", onBack) {
        item {
            MCard {
                Text("Experimental personal wellness estimate", style = MaterialTheme.typography.labelLarge)
                if (res.score == null) {
                    Text("Not enough data", style = MaterialTheme.typography.headlineMedium)
                    EmptyState("Add last night's sleep to calculate an estimate.", "Add sleep record") { go("sleep") }
                } else {
                    Text("${res.score} / 100", style = MaterialTheme.typography.headlineMedium)
                    if (res.avgActiveMinutes == null) Caption("Based on sleep only. No exercise minutes in the last 3 days.")
                }
            }
        }
        item {
            MCard {
                Text("Inputs", style = MaterialTheme.typography.titleMedium)
                Text("Sleep (last night): " + (sleepMin?.let { SleepCalc.format(it) } ?: "missing"))
                Text("Exercise (3-day average): " + (res.avgActiveMinutes?.let { "${fmt(it)} min/day" } ?: "missing, optional"))
                Text("Not used: heart rate, heart rate variability, sleep stages, or any sensor data.")
            }
        }
        item {
            MCard {
                Text("How it is calculated", style = MaterialTheme.typography.titleMedium)
                Text("Sleep points = 60 × min(sleep hours ÷ 8, 1).")
                Text("Activity points = 40 × min(average daily exercise minutes over 3 days ÷ 30, 1).")
                Text("Score = points earned ÷ points available × 100. If no exercise is recorded, only sleep is used.")
            }
        }
        item {
            MCard {
                Text("Limitations", style = MaterialTheme.typography.titleMedium)
                Text("This is a simple formula, not a clinically validated score. It does not measure your real energy level, recovery or health, and it is not equivalent to scores from Samsung Health, Apple Health or any other product. It cannot diagnose or rule out any condition.")
            }
        }
    }
}

@Composable
fun CardioScreen(vm: AppViewModel, onBack: () -> Unit, go: (String) -> Unit) {
    val acts by vm.activities.collectAsStateWithLifecycle()
    val today = LocalDate.now()
    val days = (6 downTo 0).map { today.minusDays(it.toLong()) }
    val loads = days.map { ActivityLoad.forDate(acts, it) }
    val excluded = acts.count { it.minutes > 0 && ActivityLoad.factor(it.intensity) == null }

    Screen("Daily cardio load", onBack) {
        item {
            MCard {
                Text("Activity-load estimate", style = MaterialTheme.typography.labelLarge)
                if (loads.all { it == 0 }) EmptyState("Add exercise minutes with an intensity to see an estimate.", "Add activity") { go("activity") }
                else {
                    Text("Today: ${loads.last()} AU", style = MaterialTheme.typography.headlineMedium)
                    Text("Last 7 days: ${loads.sum()} AU")
                    Spacer(Modifier.height(8.dp))
                    BarChart(loads.map { it.toFloat() }, days.map { dayLabel(it) }, Tints.Cardio)
                }
                if (excluded > 0) Caption("$excluded entr${if (excluded == 1) "y" else "ies"} without an intensity not counted.")
            }
        }
        item {
            MCard {
                Text("How it is calculated", style = MaterialTheme.typography.titleMedium)
                Text("Load = exercise minutes × intensity factor (Low 1, Moderate 2, High 3), summed per day. Units are arbitrary (AU).")
            }
        }
        item {
            MCard {
                Text("Limitations", style = MaterialTheme.typography.titleMedium)
                Text("This is an estimate from the activities and intensities you enter. It is not measured heart strain, not actual cardiovascular load and not clinically validated. No heart rate data is used.")
            }
        }
    }
}

@Composable
fun VascularScreen(vm: AppViewModel, onBack: () -> Unit, go: (String) -> Unit) {
    val records by vm.records.collectAsStateWithLifecycle()
    val related = records.filter { it.category == "Blood pressure" || it.category == "Heart rate" }

    Screen("Vascular load", onBack) {
        item {
            MCard {
                Text("No score available", style = MaterialTheme.typography.headlineSmall)
                Text("A validated vascular-load score needs an appropriate measurement method and a reliable data source. MEDRATE has neither, so it does not calculate one and does not estimate vascular health from steps, sleep or other data.")
            }
        }
        item {
            MCard {
                Text("Your entered measurements", style = MaterialTheme.typography.titleMedium)
                if (related.isEmpty()) EmptyState("No blood pressure or heart rate records yet.", "Add a health record") { go("records") }
                else {
                    related.take(10).forEach {
                        Text("${friendlyDate(LocalDate.parse(it.date))} · ${it.title}" + (it.value?.let { v -> " · ${fmt(v)} ${it.unit}".trimEnd() } ?: ""))
                    }
                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(onClick = { go("records") }) { Text("Open health records") }
                }
                Caption("Shown exactly as you entered them. No interpretation is made.")
            }
        }
        item {
            MCard {
                Text("Please note", style = MaterialTheme.typography.titleMedium)
                Text("MEDRATE makes no claims about arterial stiffness or cardiovascular disease. Discuss your measurements with a qualified health professional.")
            }
        }
    }
}
