package com.medrate.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.medrate.app.ai.*
import com.medrate.app.ui.components.*
import kotlinx.coroutines.launch

private val education = listOf(
    "When to seek urgent care" to "Call your local emergency number or go to emergency care right away for chest pain or pressure, trouble breathing, signs of a stroke (face drooping, arm weakness, speech difficulty, sudden confusion), severe bleeding, fainting, signs of a severe allergic reaction (swelling of the face or throat, trouble breathing), or thoughts of harming yourself. Do not wait for an app.",
    "Understanding symptoms" to "A symptom can have many possible causes, from minor to serious. General information cannot tell which applies to you. Note when it started, how it changes and anything that makes it better or worse, and share this with a doctor or pharmacist. If symptoms are severe, sudden or worsening, seek care promptly.",
    "Medication safety basics" to "Take medicines exactly as directed on the label or by your prescriber. Do not change a dose or stop a prescribed medicine without advice from a doctor or pharmacist. Ask a pharmacist about interactions, including over-the-counter products and supplements. Keep an up-to-date list of what you take, store medicines as the label says, and never share prescriptions.",
    "Talking with your clinician" to "Useful questions: What is this medicine for? When and how should I take it? What should I do if I miss a dose? What side effects should I watch for? Does it interact with anything else I take? When should I follow up?"
)

@Composable
fun AssistantScreen(onBack: () -> Unit) {
    val provider = AiConfig.provider
    val scope = rememberCoroutineScope()
    var mode by remember { mutableStateOf(AssistantMode.GENERAL) }
    var consent by remember { mutableStateOf(false) }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val messages = remember { mutableStateListOf<ChatMessage>() }
    var open by remember { mutableStateOf<String?>(null) }
    val canChat = provider.isConfigured && consent && !busy

    Screen("AI Health Assistant", onBack) {
        item {
            MCard {
                Text(if (provider.isConfigured) "Provider: ${provider.name}" else "No AI provider is configured", style = MaterialTheme.typography.titleMedium)
                Text(
                    if (provider.isConfigured) "Answers come from an external AI service. They are general information, not medical advice or a diagnosis."
                    else "Chat is disabled and no AI model is running. The static health education below works offline. See the README to connect a provider."
                )
                if (provider.isConfigured && !consent) {
                    Spacer(Modifier.height(8.dp))
                    Text("Your typed messages will be sent to ${provider.name}. Saved health records are never attached.")
                    Button(onClick = { consent = true }) { Text("I agree") }
                }
            }
        }
        item { ChipRow(AssistantMode.values().map { it.label }, mode.label) { l -> mode = AssistantMode.values().first { it.label == l } } }
        item {
            MCard {
                if (messages.isEmpty()) EmptyState("No messages yet.")
                messages.forEach {
                    Text((if (it.fromUser) "You: " else "Assistant: ") + it.text, Modifier.padding(vertical = 4.dp))
                }
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = input, onValueChange = { input = it }, enabled = canChat, modifier = Modifier.weight(1f),
                        placeholder = { Text(if (provider.isConfigured) "Ask a general question" else "Chat unavailable") }
                    )
                    Button(enabled = canChat && input.isNotBlank(), onClick = {
                        messages.add(ChatMessage(true, input.trim())); input = ""; busy = true
                        scope.launch {
                            try { messages.add(ChatMessage(false, provider.reply(mode, messages.toList()))) }
                            catch (e: Exception) { messages.add(ChatMessage(false, "The assistant could not answer right now.")) }
                            busy = false
                        }
                    }) { Text("Send") }
                }
                Caption("Messages are not saved. Never share emergency situations here; call your local emergency number.")
            }
        }
        item { SectionTitle("Health education (offline)") }
        education.forEach { (title, body) ->
            item(key = title) {
                MCard(onClick = { open = if (open == title) null else title }) {
                    Text(title, style = MaterialTheme.typography.titleMedium)
                    if (open == title) Text(body)
                }
            }
        }
        item { Caption("General information only. It does not replace professional medical care.") }
    }
}
