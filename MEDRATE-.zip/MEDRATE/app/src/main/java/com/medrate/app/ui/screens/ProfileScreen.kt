package com.medrate.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.medrate.app.ui.components.*
import com.medrate.app.viewmodels.AppViewModel

@Composable
fun ProfileScreen(vm: AppViewModel) {
    val s by vm.settings.collectAsStateWithLifecycle()
    var name by remember(s.name) { mutableStateOf(s.name) }
    var dialog by remember { mutableStateOf<String?>(null) }

    Screen("Profile") {
        item {
            MCard {
                Text("Display name", style = MaterialTheme.typography.titleMedium)
                Field("Name", name, { name = it })
                Spacer(Modifier.height(8.dp))
                Button(onClick = { vm.setName(name.trim()) }) { Text("Save name") }
            }
        }
        item {
            MCard {
                Text("Appearance", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                ChipRow(listOf("System", "Light", "Dark"), s.theme.replaceFirstChar { it.uppercase() }) { vm.setTheme(it.lowercase()) }
            }
        }
        item {
            MCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Medication reminders", style = MaterialTheme.typography.titleMedium)
                        Caption("Turning this off cancels all scheduled reminders.")
                    }
                    Switch(checked = s.remindersEnabled, onCheckedChange = { vm.setReminders(it) })
                }
            }
        }
        item { MCard(onClick = { dialog = "privacy" }) { Text("Health-data privacy notice", style = MaterialTheme.typography.titleMedium) } }
        item { MCard(onClick = { dialog = "about" }) { Text("About MEDRATE", style = MaterialTheme.typography.titleMedium) } }
        item {
            MCard {
                Text("Local data", style = MaterialTheme.typography.titleMedium)
                Caption("Everything is stored on this device only.")
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = { dialog = "delete" }) { Text("Delete all health data", color = MaterialTheme.colorScheme.error) }
            }
        }
        item { Caption("MEDRATE does not replace professional medical care. It does not diagnose, treat or prescribe.") }
    }

    when (dialog) {
        "privacy" -> InfoDialog("Privacy notice",
            "MEDRATE stores the information you enter (medicines, dose history, activity, sleep, meals, health records and your display name) only on this device. There is no account, no cloud sync, no analytics and no sharing with servers. Backups are disabled for the app. Uninstalling the app or using Delete all health data removes the data.") { dialog = null }
        "about" -> InfoDialog("About MEDRATE",
            "Version 1.0.0. A personal health dashboard and medication manager. MEDRATE is an independent app and is not affiliated with Samsung or Apple. It does not replace professional medical care. Energy score and cardio load are simple experimental estimates, not clinical measurements.") { dialog = null }
        "delete" -> AlertDialog(
            onDismissRequest = { dialog = null },
            title = { Text("Delete all health data?") },
            text = { Text("This permanently deletes every medicine, dose record, activity, sleep entry, meal and health record, and cancels all reminders. This cannot be undone.") },
            confirmButton = { TextButton(onClick = { vm.deleteAll(); dialog = null }) { Text("Delete everything", color = MaterialTheme.colorScheme.error) } },
            dismissButton = { TextButton(onClick = { dialog = null }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun InfoDialog(title: String, body: String, onClose: () -> Unit) {
    AlertDialog(
        onDismissRequest = onClose, title = { Text(title) }, text = { Text(body) },
        confirmButton = { TextButton(onClick = onClose) { Text("Close") } }
    )
}
