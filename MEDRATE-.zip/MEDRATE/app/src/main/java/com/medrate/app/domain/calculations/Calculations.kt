package com.medrate.app.domain.calculations

import com.medrate.app.data.entities.*
import java.time.*

object SleepCalc {
    fun minutesBetween(bed: LocalDateTime, wake: LocalDateTime): Long = Duration.between(bed, wake).toMinutes()
    fun minutesBetween(startMillis: Long, endMillis: Long): Long = (endMillis - startMillis) / 60_000

    /** Wake time lands on [wakeDate]; bed time is the previous evening when it is not earlier than the wake time. */
    fun resolve(wakeDate: LocalDate, bed: LocalTime, wake: LocalTime): Pair<LocalDateTime, LocalDateTime> {
        val w = LocalDateTime.of(wakeDate, wake)
        val b = if (bed >= wake) LocalDateTime.of(wakeDate.minusDays(1), bed) else LocalDateTime.of(wakeDate, bed)
        return b to w
    }

    fun isValid(minutes: Long) = minutes in 1..(20 * 60)
    fun format(minutes: Long) = "${minutes / 60}h ${minutes % 60}m"
    fun toMillis(t: LocalDateTime): Long = t.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
    fun fromMillis(ms: Long): LocalDateTime = LocalDateTime.ofInstant(Instant.ofEpochMilli(ms), ZoneId.systemDefault())
}

data class EnergyResult(val score: Int?, val sleepHours: Double?, val avgActiveMinutes: Double?)

/**
 * Experimental wellness estimate (NOT clinically validated).
 * sleep points    = 60 * min(sleepHours / 8, 1)
 * activity points = 40 * min(avgDailyActiveMinutes(3 days) / 30, 1)
 * score = available points / available maximum * 100. Sleep is required; activity is optional.
 */
object EnergyScore {
    const val SLEEP_MAX = 60.0
    const val ACTIVITY_MAX = 40.0

    fun estimate(sleepMinutes: Long?, activeMinutesLast3Days: Int?): EnergyResult {
        if (sleepMinutes == null || sleepMinutes <= 0) return EnergyResult(null, null, null)
        val hours = sleepMinutes / 60.0
        val sleepPts = SLEEP_MAX * minOf(hours / 8.0, 1.0)
        if (activeMinutesLast3Days == null) {
            return EnergyResult(Math.round(sleepPts / SLEEP_MAX * 100).toInt(), hours, null)
        }
        val avg = activeMinutesLast3Days / 3.0
        val actPts = ACTIVITY_MAX * minOf(avg / 30.0, 1.0)
        return EnergyResult(Math.round(sleepPts + actPts).toInt(), hours, avg)
    }
}

/** Arbitrary-unit activity load estimate: minutes x intensity factor (Low 1, Moderate 2, High 3). */
object ActivityLoad {
    fun factor(intensity: String): Int? = when (intensity) {
        "LOW" -> 1
        "MODERATE" -> 2
        "HIGH" -> 3
        else -> null
    }

    fun load(minutes: Int, intensity: String): Int? = factor(intensity)?.let { it * minutes }
    fun forDate(entries: List<ActivityEntry>, date: LocalDate): Int =
        entries.filter { it.date == date.toString() }.sumOf { load(it.minutes, it.intensity) ?: 0 }
}

object Summaries {
    fun stepsOn(a: List<ActivityEntry>, d: LocalDate) = a.filter { it.date == d.toString() }.sumOf { it.steps }
    fun minutesOn(a: List<ActivityEntry>, d: LocalDate) = a.filter { it.date == d.toString() }.sumOf { it.minutes }

    fun latestSleepMinutes(s: List<SleepEntry>, today: LocalDate): Long? =
        s.filter { it.wakeDate() == today || it.wakeDate() == today.minusDays(1) }
            .maxByOrNull { it.endMillis }?.let { SleepCalc.minutesBetween(it.startMillis, it.endMillis) }

    /** Null when no exercise minutes were recorded in the last three days. */
    fun activeMinutes3Day(a: List<ActivityEntry>, today: LocalDate): Int? {
        val days = (0..2).map { today.minusDays(it.toLong()).toString() }
        val inWindow = a.filter { it.date in days && it.minutes > 0 }
        return if (inWindow.isEmpty()) null else inWindow.sumOf { it.minutes }
    }

    data class Recent(val millis: Long, val text: String)

    fun recent(s: List<SleepEntry>, a: List<ActivityEntry>, m: List<MealEntry>, r: List<HealthRecord>): List<Recent> {
        val z = ZoneId.systemDefault()
        fun day(d: String) = LocalDate.parse(d).atStartOfDay(z).toInstant().toEpochMilli()
        val all = s.map { Recent(it.endMillis, "Sleep · ${SleepCalc.format(SleepCalc.minutesBetween(it.startMillis, it.endMillis))}") } +
            a.map { Recent(day(it.date), "${it.type} · ${it.steps} steps, ${it.minutes} min") } +
            m.map { Recent(it.dateTimeMillis, "${it.category} · ${it.name}") } +
            r.map { Recent(day(it.date), "Record · ${it.title}") }
        return all.sortedByDescending { it.millis }.take(5)
    }
}

data class DoseItem(val medicine: Medicine, val date: LocalDate, val time: String, val status: String)

object Doses {
    const val PENDING = "PENDING"
    const val TAKEN = "TAKEN"
    const val SKIPPED = "SKIPPED"

    fun active(m: Medicine, d: LocalDate): Boolean =
        !d.isBefore(LocalDate.parse(m.startDate)) && (m.endDate == null || !d.isAfter(LocalDate.parse(m.endDate)))

    fun forDate(date: LocalDate, meds: List<Medicine>, logs: List<DoseLog>): List<DoseItem> =
        meds.filter { active(it, date) }.flatMap { m ->
            m.timeList().map { t ->
                val st = logs.firstOrNull { it.medicineId == m.id && it.date == date.toString() && it.time == t }?.status ?: PENDING
                DoseItem(m, date, t, st)
            }
        }.sortedBy { it.time }

    /** Returns (taken, due) over the last [days] days, counting only doses whose time has passed. */
    fun adherence(meds: List<Medicine>, logs: List<DoseLog>, today: LocalDate, now: LocalDateTime, days: Int = 7): Pair<Int, Int> {
        var taken = 0
        var due = 0
        for (i in 0 until days) {
            val d = today.minusDays(i.toLong())
            for (item in forDate(d, meds, logs)) {
                if (!LocalDateTime.of(d, LocalTime.parse(item.time)).isAfter(now)) {
                    due++
                    if (item.status == TAKEN) taken++
                }
            }
        }
        return taken to due
    }
}
