package com.medrate.app.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.medrate.app.domain.calculations.*
import com.medrate.app.ui.components.*
import com.medrate.app.viewmodels.AppViewModel
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter

private val Ink = Color(0xFF20232A)
private val Muted = Color(0xFF7C8492)
private val Blue = Color(0xFF62B5F5)
private val Coral = Color(0xFFFF8C82)
private val Mint = Color(0xFF75D8C1)
private val Lilac = Color(0xFFB8B8F6)

@Composable
fun HomeScreen(vm: AppViewModel, go: (String) -> Unit) {
    val meds by vm.medicines.collectAsStateWithLifecycle()
    val logs by vm.doseLogs.collectAsStateWithLifecycle()
    val acts by vm.activities.collectAsStateWithLifecycle()
    val sleeps by vm.sleeps.collectAsStateWithLifecycle()
    val meals by vm.meals.collectAsStateWithLifecycle()
    val records by vm.records.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()

    val today = LocalDate.now()
    val doses = remember(meds, logs) { Doses.forDate(today, meds, logs) }
    val taken = doses.count { it.status == Doses.TAKEN }
    val next = doses.firstOrNull { it.status == Doses.PENDING && LocalTime.parse(it.time) >= LocalTime.now() }
    val steps = Summaries.stepsOn(acts, today)
    val minutes = Summaries.minutesOn(acts, today)
    val sleepMin = Summaries.latestSleepMinutes(sleeps, today)
    val energy = remember(sleeps, acts) { EnergyScore.estimate(sleepMin, Summaries.activeMinutes3Day(acts, today)) }
    val load = ActivityLoad.forDate(acts, today)
    val todayMeals = meals.filter { SleepCalc.fromMillis(it.dateTimeMillis).toLocalDate() == today }
    val kcal = todayMeals.mapNotNull { it.calories }.sum()
    val recent = remember(sleeps, acts, meals, records) { Summaries.recent(sleeps, acts, meals, records) }
    val hasActivity = acts.any { it.date == today.toString() }
    val dateLabel = today.format(DateTimeFormatter.ofPattern("EEEE, d MMMM"))

    Screen(title = "MEDRATE", subtitle = dateLabel) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(if (settings.name.isBlank()) "Your health summary" else "Your health summary, ${settings.name}", style = MaterialTheme.typography.headlineSmall, color = Ink)
                Text("Small steps, better habits.", style = MaterialTheme.typography.bodyMedium, color = Muted)
            }
        }
        item {
            Surface(color = Blue, shape = RoundedCornerShape(28.dp), modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("WELLNESS ESTIMATE", color = Color.White.copy(alpha = .85f), style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(10.dp))
                        Text(energy.score?.toString() ?: "—", color = Color.White, style = MaterialTheme.typography.displayMedium, fontWeight = FontWeight.Light)
                        Text(if (energy.score == null) "Add sleep data to get started" else "Estimated daily score · not a medical measurement", color = Color.White, style = MaterialTheme.typography.bodySmall)
                    }
                    Box(Modifier.size(94.dp), contentAlignment = Alignment.Center) {
                        Canvas(Modifier.fillMaxSize()) {
                            drawArc(Color.White.copy(alpha = .28f), -90f, 360f, false, style = androidx.compose.ui.graphics.drawscope.Stroke(12.dp.toPx(), cap = StrokeCap.Round))
                            if (energy.score != null) drawArc(Color.White, -90f, 360f * energy.score.coerceIn(0, 100) / 100f, false, style = androidx.compose.ui.graphics.drawscope.Stroke(12.dp.toPx(), cap = StrokeCap.Round))
                        }
                        Text(if (energy.score == null) "—" else "${energy.score}%", color = Color.White, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
        item {
            Text("Your vitals", style = MaterialTheme.typography.titleLarge, color = Ink, fontWeight = FontWeight.SemiBold)
            Surface(color = Color(0xFFFFF8F0), shape = RoundedCornerShape(26.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Health data overview", style = MaterialTheme.typography.titleMedium, color = Ink)
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        VitalPill("♥", "Heart rate", "No data", Coral, Modifier.weight(1f))
                        VitalPill("◷", "Sleep", sleepMin?.let { SleepCalc.format(it) } ?: "No data", Lilac, Modifier.weight(1f))
                        VitalPill("✓", "Medication", if (doses.isEmpty()) "No schedule" else "$taken/${doses.size}", Mint, Modifier.weight(1f))
                    }
                    Text("Heart rate isn't connected to a sensor. No value is being estimated.", color = Muted, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        item {
            Surface(color = Color(0xFFF1F6FC), shape = RoundedCornerShape(26.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.weight(1f)) {
                            Text("Activity", style = MaterialTheme.typography.titleMedium, color = Ink)
                            Text("Today's movement", color = Muted, style = MaterialTheme.typography.bodySmall)
                        }
                        Text(if (hasActivity) "$steps" else "—", color = Color(0xFF247EC0), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.SemiBold)
                    }
                    MiniBars()
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(if (hasActivity) "$minutes min active" else "No activity logged", color = Muted, style = MaterialTheme.typography.bodySmall)
                        Text("View details  ›", color = Color(0xFF247EC0), style = MaterialTheme.typography.labelLarge)
                    }
                    TextButton(onClick = { go("activity") }) { Text("Open activity") }
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                DashboardTile("Sleep", sleepMin?.let { SleepCalc.format(it) } ?: "—", "Rest and recovery", Lilac, Modifier.weight(1f)) { go("sleep") }
                DashboardTile("Food", if (kcal > 0) "$kcal kcal" else "Add meal", if (todayMeals.isEmpty()) "Log what you eat" else "${todayMeals.size} meal(s) logged", Coral, Modifier.weight(1f)) { go("food") }
            }
        }
        item {
            Surface(color = Color(0xFFE8F8F3), shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp)) {
                    Text("Medication", style = MaterialTheme.typography.titleMedium, color = Ink)
                    Spacer(Modifier.height(4.dp))
                    Text(when {
                        meds.isEmpty() -> "Add medication to set reminders."
                        doses.isEmpty() -> "No doses scheduled today."
                        next != null -> "$taken of ${doses.size} taken · next ${next.time} (${next.medicine.name})"
                        else -> "$taken of ${doses.size} doses taken today"
                    }, color = Muted)
                    TextButton(onClick = { go("medication") }) { Text("Manage medication") }
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                DashboardTile("Cardio load", if (load > 0) "$load AU" else "—", "Estimate from logged activity", Blue, Modifier.weight(1f)) { go("cardio") }
                DashboardTile("Records", "${records.size}", "Saved health records", Color(0xFFB5C5D7), Modifier.weight(1f)) { go("records") }
            }
        }
        item {
            Surface(color = Color(0xFFF5F0FF), shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("AI Health Assistant", color = Ink, style = MaterialTheme.typography.titleMedium)
                        Text("General health information · setup pending", color = Muted, style = MaterialTheme.typography.bodySmall)
                    }
                    TextButton(onClick = { go("assistant") }) { Text("Open  ›") }
                }
            }
        }
        item { Text("Recent activity", style = MaterialTheme.typography.titleLarge, color = Ink, fontWeight = FontWeight.SemiBold) }
        if (recent.isEmpty()) item { MCard { EmptyState("Nothing logged yet. Your entries will appear here.") } }
        else item {
            MCard {
                recent.forEachIndexed { i, r ->
                    if (i > 0) HorizontalDivider(Modifier.padding(vertical = 8.dp))
                    Text(r.text, color = Ink)
                    Caption(friendlyDate(SleepCalc.fromMillis(r.millis).toLocalDate()))
                }
            }
        }
    }
}

@Composable
private fun VitalPill(icon: String, title: String, value: String, tint: Color, modifier: Modifier = Modifier) {
    Column(modifier.clip(RoundedCornerShape(18.dp)).background(Color.White).padding(vertical = 12.dp, horizontal = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(30.dp).clip(CircleShape).background(tint), contentAlignment = Alignment.Center) { Text(icon, color = Color.White, fontWeight = FontWeight.Bold) }
        Spacer(Modifier.height(7.dp))
        Text(value, color = Ink, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold)
        Text(title, color = Muted, style = MaterialTheme.typography.labelSmall, maxLines = 1)
    }
}

@Composable
private fun DashboardTile(title: String, value: String, subtitle: String, tint: Color, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Surface(onClick = onClick, color = tint.copy(alpha = .25f), shape = RoundedCornerShape(24.dp), modifier = modifier) {
        Column(Modifier.padding(16.dp).heightIn(min = 112.dp), verticalArrangement = Arrangement.SpaceBetween) {
            Text(title, color = Ink, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
            Column {
                Text(value, color = Ink, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Medium)
                Text(subtitle, color = Muted, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun MiniBars() {
    val heights = listOf(.32f, .44f, .25f, .58f, .42f, .7f, .37f, .53f, .29f, .62f, .46f, .78f, .39f, .57f)
    Row(Modifier.fillMaxWidth().height(62.dp), horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.Bottom) {
        heights.forEachIndexed { i, h ->
            Box(Modifier.weight(1f).fillMaxHeight(h).clip(RoundedCornerShape(8.dp)).background(if (i == 11) Color(0xFF2B8ED0) else Color(0xFF9CCFF0)))
        }
    }
    Text("Illustrative visual only · not measured sensor data", color = Muted, style = MaterialTheme.typography.labelSmall)
}
