package com.medrate.app.ui.theme

import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

/** Category tints used on dashboard cards (white text on top). */
object Tints {
    val Energy = Color(0xFF2F6FDE)
    val Activity = Color(0xFF0E8C97)
    val Sleep = Color(0xFF4B4FB8)
    val Food = Color(0xFFD9822B)
    val Medication = Color(0xFF3E9B4F)
    val Records = Color(0xFF4E5D6C)
    val Cardio = Color(0xFF1E6FB5)
    val Vascular = Color(0xFFB8507F)
    val Assistant = Color(0xFF0E7C9B)
}

private val Light = lightColorScheme(
    primary = Color(0xFF0E7C9B), onPrimary = Color.White,
    secondary = Color(0xFF2F6FDE), tertiary = Color(0xFF3E9B4F),
    background = Color(0xFFF6F7F9), surface = Color.White,
    onBackground = Color(0xFF111827), onSurface = Color(0xFF111827),
    surfaceVariant = Color(0xFFE9EDF2), onSurfaceVariant = Color(0xFF5B6574),
    outlineVariant = Color(0xFFE2E6EC)
)
private val Dark = darkColorScheme(
    primary = Color(0xFF5CC4DE), onPrimary = Color(0xFF00343F),
    secondary = Color(0xFF8DB2FF), tertiary = Color(0xFF7ED08C),
    background = Color(0xFF0E1116), surface = Color(0xFF171B22),
    onBackground = Color(0xFFEDEFF3), onSurface = Color(0xFFEDEFF3),
    surfaceVariant = Color(0xFF262C36), onSurfaceVariant = Color(0xFF9AA4B2),
    outlineVariant = Color(0xFF2A303A)
)

@Composable
fun MedrateTheme(theme: String, content: @Composable () -> Unit) {
    val dark = when (theme) { "dark" -> true; "light" -> false; else -> isSystemInDarkTheme() }
    val activity = LocalContext.current as ComponentActivity
    DisposableEffect(dark) {
        val style = SystemBarStyle.auto(android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT) { dark }
        activity.enableEdgeToEdge(statusBarStyle = style, navigationBarStyle = style)
        onDispose { }
    }
    val base = Typography()
    val typography = base.copy(
        headlineLarge = base.headlineLarge.copy(fontWeight = FontWeight.Bold),
        headlineMedium = base.headlineMedium.copy(fontWeight = FontWeight.Bold),
        headlineSmall = base.headlineSmall.copy(fontWeight = FontWeight.SemiBold),
        titleMedium = base.titleMedium.copy(fontWeight = FontWeight.SemiBold)
    )
    MaterialTheme(
        colorScheme = if (dark) Dark else Light,
        typography = typography,
        shapes = Shapes(
            small = RoundedCornerShape(12.dp), medium = RoundedCornerShape(16.dp), large = RoundedCornerShape(24.dp)
        ),
        content = content
    )
}
