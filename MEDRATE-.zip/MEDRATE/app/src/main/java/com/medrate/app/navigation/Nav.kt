package com.medrate.app.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Favorite
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.medrate.app.ui.screens.*
import com.medrate.app.viewmodels.AppViewModel

private data class TopItem(val route: String, val label: String, val icon: androidx.compose.ui.graphics.vector.ImageVector)

private val topItems = listOf(
    TopItem("home", "Home", Icons.Outlined.Home),
    TopItem("medication", "Medication", Icons.Outlined.Notifications),
    TopItem("health", "Health", Icons.Outlined.Favorite),
    TopItem("profile", "Profile", Icons.Outlined.Person)
)

private fun parentOf(route: String) = when (route) {
    "home", "medication", "profile" -> route
    else -> "health"
}

@Composable
fun MedrateApp(vm: AppViewModel) {
    val nav = rememberNavController()
    val snack = remember { SnackbarHostState() }
    val msg by vm.message.collectAsStateWithLifecycle()
    LaunchedEffect(msg) { msg?.let { snack.showSnackbar(it); vm.clearMessage() } }
    val entry by nav.currentBackStackEntryAsState()
    val route = entry?.destination?.route ?: "home"

    fun go(r: String) {
        if (topItems.any { it.route == r }) {
            nav.navigate(r) {
                popUpTo(nav.graph.findStartDestination().id) { saveState = true }
                launchSingleTop = true
                restoreState = true
            }
        } else nav.navigate(r) { launchSingleTop = true }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snack) },
        bottomBar = {
            NavigationBar {
                topItems.forEach {
                    NavigationBarItem(
                        selected = parentOf(route) == it.route,
                        onClick = { go(it.route) },
                        icon = { Icon(it.icon, contentDescription = null) },
                        label = { Text(it.label) }
                    )
                }
            }
        }
    ) { pad ->
        val back: () -> Unit = { nav.popBackStack() }
        NavHost(nav, startDestination = "home", modifier = Modifier.padding(pad)) {
            composable("home") { HomeScreen(vm, ::go) }
            composable("medication") { MedicationScreen(vm) }
            composable("health") { HealthHubScreen(::go) }
            composable("profile") { ProfileScreen(vm) }
            composable("sleep") { SleepScreen(vm, back) }
            composable("activity") { ActivityScreen(vm, back) }
            composable("food") { FoodScreen(vm, back) }
            composable("records") { RecordsScreen(vm, back) }
            composable("energy") { EnergyScreen(vm, back, ::go) }
            composable("cardio") { CardioScreen(vm, back, ::go) }
            composable("vascular") { VascularScreen(vm, back, ::go) }
            composable("assistant") { AssistantScreen(back) }
        }
    }
}
