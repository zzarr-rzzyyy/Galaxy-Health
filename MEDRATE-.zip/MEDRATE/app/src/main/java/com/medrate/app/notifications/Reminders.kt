package com.medrate.app.notifications

import android.annotation.SuppressLint
import android.app.*
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.medrate.app.MainActivity
import com.medrate.app.R
import com.medrate.app.data.database.AppDatabase
import com.medrate.app.data.entities.Medicine
import com.medrate.app.data.repositories.SettingsStore
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.first
import java.time.*

object Reminders {
    const val CHANNEL_ID = "medication_reminders"

    fun ensureChannel(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Medication reminders", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Reminders for the medicines you add in MEDRATE"
            }
        )
    }

    fun requestCode(medId: Long, time: String): Int = medId.toInt() * 10000 + time.replace(":", "").toInt()

    private fun pending(ctx: Context, medId: Long, time: String): PendingIntent {
        val i = Intent(ctx, ReminderReceiver::class.java).putExtra("medId", medId).putExtra("time", time)
        return PendingIntent.getBroadcast(
            ctx, requestCode(medId, time), i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun nextTrigger(m: Medicine, time: String, now: LocalDateTime): LocalDateTime? {
        val t = LocalTime.parse(time)
        val start = LocalDate.parse(m.startDate)
        val end = m.endDate?.let { LocalDate.parse(it) }
        var c = LocalDateTime.of(maxOf(now.toLocalDate(), start), t)
        if (!c.isAfter(now)) c = c.plusDays(1)
        if (end != null && c.toLocalDate().isAfter(end)) return null
        return c
    }

    /** Inexact, doze-friendly alarm: delivery may be delayed by Android and is never guaranteed on the minute. */
    fun scheduleOne(ctx: Context, m: Medicine, time: String) {
        val next = nextTrigger(m, time, LocalDateTime.now()) ?: return
        val am = ctx.getSystemService(AlarmManager::class.java)
        val at = next.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pending(ctx, m.id, time))
    }

    fun schedule(ctx: Context, m: Medicine) = m.timeList().forEach { scheduleOne(ctx, m, it) }

    fun cancel(ctx: Context, m: Medicine) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        m.timeList().forEach { val pi = pending(ctx, m.id, it); am.cancel(pi); pi.cancel() }
    }

    fun scheduleAll(ctx: Context, meds: List<Medicine>) = meds.forEach { schedule(ctx, it) }
    fun cancelAll(ctx: Context, meds: List<Medicine>) = meds.forEach { cancel(ctx, it) }

    suspend fun rescheduleFromDb(ctx: Context) {
        val enabled = SettingsStore(ctx).settings.first().remindersEnabled
        if (enabled) scheduleAll(ctx, AppDatabase.get(ctx).dao().medicinesOnce())
    }

    @SuppressLint("MissingPermission")
    fun show(ctx: Context, m: Medicine, time: String) {
        val nmc = NotificationManagerCompat.from(ctx)
        if (!nmc.areNotificationsEnabled()) return
        ensureChannel(ctx)
        val open = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(ctx, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("Medication reminder: ${m.name}")
            .setContentText("Scheduled for $time. Open MEDRATE to record it.")
            .setContentIntent(open)
            .setAutoCancel(true)
            .setVisibility(NotificationCompat.VISIBILITY_PRIVATE)
            .build()
        nmc.notify(requestCode(m.id, time), n)
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val id = intent.getLongExtra("medId", -1)
        val time = intent.getStringExtra("time") ?: return
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val enabled = SettingsStore(ctx).settings.first().remindersEnabled
                val m = AppDatabase.get(ctx).dao().medicine(id)
                if (enabled && m != null && time in m.timeList()) {
                    Reminders.show(ctx, m, time)
                    Reminders.scheduleOne(ctx, m, time) // next day
                }
            } finally {
                pending.finish()
            }
        }
    }
}

/** Reschedules after reboot, time change and timezone change. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try { Reminders.rescheduleFromDb(ctx) } finally { pending.finish() }
        }
    }
}
