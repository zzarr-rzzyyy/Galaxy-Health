# MEDRATE

Personal health dashboard and medication manager for Android (Kotlin, Jetpack Compose, Material 3, Room, DataStore, MVVM).
Package `com.medrate.app` · min SDK 26 · compile/target SDK 35 · JVM 17.

> **Build status: not verified.** The project was written without network access and has never been compiled.
> Expect that a few small compile errors may need fixing on the first build. Open the GitHub Actions log or Android Studio's
> Build output and fix them.

## Build the APK with GitHub Actions
1. Create a new GitHub repository and upload the **contents** of this folder (keep the `.github` folder).
2. Open the **Actions** tab, select **Android CI** and run it (it also runs on every push to `main`/`master`).
3. When finished, open the run and download the artifact **medrate-debug-apk** (`app-debug.apk`).
4. Copy the APK to your phone and install it (allow "install unknown apps").

The workflow installs Gradle 8.9 itself, so no Gradle wrapper files are required.

## Build in Android Studio
Open the folder in Android Studio (Ladybug or newer, JDK 17), let Gradle sync, then Run or Build > Build APK(s).
The APK is at `app/build/outputs/apk/debug/app-debug.apk`. Optionally run *Tools > Create Gradle Wrapper* to add a wrapper.

## Notifications
On Android 13+ the app asks for notification permission from the Medication tab. Reminders are scheduled with
`AlarmManager.setAndAllowWhileIdle`, which is inexact: Android or battery saver may delay them. They are rescheduled
after reboot, time change and timezone change. Do not rely on MEDRATE as your only reminder.

## What works
Medication CRUD, reminders, taken/skipped history and 7-day adherence; manual activity, sleep, food and health records
with charts; transparent Energy Score and Cardio Load estimates; an honest Vascular Load page (no score); health
education pages; settings, theme, privacy notice and confirmed data deletion. All data stays on the device.

## Not included
Automatic step-sensor tracking, sleep detection, nutrition lookup, cloud sync and a live AI model.

## Optional AI integration
Chat is disabled until a provider is set. Implement `ai/AiProvider` and assign it to `AiConfig.provider`.
Do **not** put API keys in the app or APK; call your own backend that holds the key. Use `SystemPrompts.forMode` as the safety
prompt. Only typed chat text is sent after in-app consent; stored health records are never attached.

## Disclaimer
MEDRATE does not replace professional medical care. It does not diagnose, treat or prescribe. Energy Score and Cardio Load
are experimental estimates, not clinical measurements. MEDRATE is not affiliated with Samsung or Apple.
